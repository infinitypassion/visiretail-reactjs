export * from './RegisterPage';
export * from './ThanksPage';