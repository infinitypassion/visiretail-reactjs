## Visiretail React JS

## Technologies
* Node JS (8.12.0)
* NPM (6.4.1)
* React JS (16.*)
* Webpack (4.*)
* Babel (7.*)

## Commands
* npm install
* npm start

## Url
* http://localhost:8080